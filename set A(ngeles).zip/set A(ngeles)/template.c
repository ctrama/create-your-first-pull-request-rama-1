#include <stdio.h>
#include <stdlib.h>
#include "graph.h"
#include "stack.h"

/*
	CREATE GRAPH
	- allocates memory for the graph
	- initializes the members of the structure + arrays
	- returns the newly created graph
*/
GRAPH * createGraph(int vertices) {
	
	//insert your implementation here
	
}

/*
	INSERT EDGE
	- plots the adjacent vertices in the adjacency matrix
*/
void insertEdge(GRAPH *G, int u, int v) {
	
	//insert your implementation here
	
}

/*
	PRINT MATRIX
	- prints the value of the adjacency matrix
*/
void printMatrix(GRAPH *G) {
	for(int i=0; i < G->num_vertices; i++) {
		for(int j=0; j < G->num_vertices; j++) {
			printf("%d\t", G->matrix[i][j]);
		}
		printf("\n");
	}
}


/*
	FREE MATRIX
	- frees the allocated memory for the adjacency matrix
*/
void freeMatrix(GRAPH *G) {
	
	//insert your implementation here
	
}

/*
	CHECK CONNECTED
	returns 1 if graph G is connected 
	otherwise, returns 0
*/

int checkConnected(GRAPH *G) {
	
	//insert your implementation here
	
}


/*
	CREATE COMPLEMENT
	computes for the complement of G 
	stores the complement in GC
*/

void createComplement(GRAPH *G, GRAPH *GC){
	
	//insert your implementation here

}


int main() {
	char command;
	int vertices, lines, u, v;

	scanf("%d", &vertices);
	GRAPH *G = createGraph(vertices);
	GRAPH *GC = createGraph(vertices);

	while(1) {
		scanf(" %c", &command);

		switch(command) {
			case '+':
				scanf(" %d %d", &u, &v);
				insertEdge(G, u-1, v-1); //there's a -1 since we use 0-indexing in the arrays
				printf("Successfully inserted edge %d %d\n", u, v);
				break;
			case '#':
				printf("\nADJACENCY MATRIX: \n");
				printMatrix(G);
				printf("\n");

				printf("Calling createComplement() function...\n");
				createComplement(G, GC);
				printf("\nADJACENCY MATRIX OF COMPLEMENT: \n");
				printMatrix(GC);
				printf("\n");

				printf("Calling checkConnected() function...\n");
				printf("The complement graph %s connected.\n", checkConnected(GC)?"is":"is NOT");
				break;
			case 'Q':
				freeMatrix(G);
				free(G);
				return 0;
			default:
				printf("Unknown command: %c\n", command);
		}
	}
}
