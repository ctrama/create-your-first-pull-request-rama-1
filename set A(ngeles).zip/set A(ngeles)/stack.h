// ___  ____    _  _ ____ ___    ____ ___  _ ___    ___ _  _ _ ____    ____ _ _    ____ 
// |  \ |  |    |\ | |  |  |     |___ |  \ |  |      |  |__| | [__     |___ | |    |___ 
// |__/ |__|    | \| |__|  |     |___ |__/ |  |      |  |  | | ___]    |    | |___ |___ 
//

/* STACK ADT */

typedef struct node_tag{
	int value;
	struct node_tag* next;
}NODE;


typedef struct stack_tag{
	NODE* head;
}STACK;


/*
** printStack()
** requirements: none
** results:
	if stack is empty, prints "*empty*"
	otherwise, prints the contents of a stack
*/
void printStack(STACK *S);


/*
** createNode()
** requirements: an integer data
** results:
	creates an empty node with value `data`
	initializes fields of the structure
	returns the created node
*/
NODE* createNode(int data);


/*
** createStack()
** requirements: none
** results:
	creates an empty stack
	initializes `head` field of the structure
	returns the created stack
*/
STACK* createStack();


/*
** isEmpty()
** requirements: none
** results:
	returns 1 if the stack is empty
	otherwise returns 0
*/
int isEmpty(STACK *S);


/*
** push()
** requirements: a stack and a node to be inserted
** results:
	inserts `node` at the top of the stack
*/
void push(STACK *S, NODE* node);


/*
** pop()
** requirements: a stack that must not be empty
** results:
	deletes top of the stack
	returns the value of the deleted node
*/
int pop(STACK *S);
